$(document).ready(function() {
 
    $("#submit").click(function() {
     
        var name = $("#name").val();
        var age = $("#age").val();
         
        if(name=='' || age=='') {
             alert("Please fill all fields.");
             return false;
        }
         
        $.ajax({
            type: "POST",
            url: "submission.php",
            data: {
                 name : name,
                 age : age
            },
            // cache: false,
            success: function(data) {
                console.log("success");
                alert(data);
            },
            error: function(xhr, status, error) {
                console.error(xhr);
            }
        });
     
    });
 
});