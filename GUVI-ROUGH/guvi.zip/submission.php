<?php
 
	/*
	* Write your logic to manage the data
	* like storing data in database
	*/
	 
	// POST Data
	$data['name'] = $_POST['name'];
	$data['age'] = $_POST['age'];
	 
	echo json_encode($data);
	exit;
 
?>